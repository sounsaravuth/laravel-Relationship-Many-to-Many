@extends('layout.Masterpage')
@section('title',"Record Product");
@section('table')
<div class="card">
    <div class="card-body">
        <form action="{{ url('updateproduct/'.$productedit->id) }}" method="POST">
            @csrf
            @method('put')
            <div class="form-group">
                <label for="Product">Product Name</label>
                <input type="text" class="form-control" name="proname" placeholder="Product name" value="{{ $productedit->proname }}">
            </div>
            <div class="form-group">
                <label for="qty">Product Qty</label>
                <input type="number" class="form-control" name="qty" placeholder="Product qty" value="{{ $productedit->qty }}">
            </div>
            <div class="form-group">
                <label for="my-select">Select Cate</label>
                <select id="my-select" class="form-control" name="categorys[]">
                    @foreach ( $fetchcate as $itemcate )
                    <option value="{{ $itemcate->id }}">{{ $itemcate->catename }}</option>
                    @endforeach

                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-info">Update Product</button>
            </div>
        </form>
    </div>
</div>

@endsection
