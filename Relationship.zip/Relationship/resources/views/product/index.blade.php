@extends('layout.Masterpage')
@section('title',"Record Product");
@section('table')
<table class="table">
    <thead>
      <tr>
        <th scope="col">Product ID</th>
        <th scope="col">Product Name</th>
        <th scope="col">Prodct Qty</th>
        <th scope="col">Categorys</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>

        @foreach ($show as $item )
        <tr>
            <th scope="row">{{ $item->id }}</th>
            <td>{{ $item->proname }}</td>
            <td>{{ $item->qty }}</td>
              {{-- loop Record category using parent loop Relationship Product --}}
            <td>@foreach ($item->categorys as $cateitem )
                    <span>{{ $cateitem->catename }}</span>
            @endforeach</td>
            <td>

                <form action="{{ url('productdelete/'.$item->id) }}" method="POST">
                    @csrf
                    @method('delete')
                    <a href="{{ url('productedit/'.$item->id) }}" class="btn btn-success">Edit</a>
                    <a href="{{ url('proshow/'.$item->id) }}" class="btn btn-success">show</a>
                    <button type="submit" class="btn btn-warning">Delete</button>
                </form>
            </td>
          </tr>
        @endforeach


    </tbody>

  </table>
@endsection
