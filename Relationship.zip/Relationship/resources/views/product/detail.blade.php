@extends('layout.Masterpage')
@section('title',"Record detail");
@section('table')
<div class="card">
    <div class="card-body">
        <ul>
            <dt>{{ $detailpro->proname }}</dt>
            <dt>{{ $detailpro->qty }}</dt>

            @foreach ($detailpro->categorys as $item )
            <dt>{{ $item->catename  }}</dt>

            @endforeach
        </ul>
    </div>
</div>

@endsection
