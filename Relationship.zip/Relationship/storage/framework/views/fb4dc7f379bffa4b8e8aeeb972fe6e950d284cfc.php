<?php $__env->startSection('title',"Record Product"); ?>;
<?php $__env->startSection('table'); ?>
<table class="table">
    <thead>
      <tr>
        <th scope="col">Product ID</th>
        <th scope="col">Product Name</th>
        <th scope="col">Prodct Qty</th>
        <th scope="col">Categorys</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($item->id); ?></th>
            <td><?php echo e($item->proname); ?></td>
            <td><?php echo e($item->qty); ?></td>
              
            <td><?php $__currentLoopData = $item->categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cateitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e($cateitem->catename); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
            <td>

                <form action="<?php echo e(url('productdelete/'.$item->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <a href="<?php echo e(url('productedit/'.$item->id)); ?>" class="btn btn-success">Edit</a>
                    <a href="<?php echo e(url('proshow/'.$item->id)); ?>" class="btn btn-success">show</a>
                    <button type="submit" class="btn btn-warning">Delete</button>
                </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>

  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Application Laravel\Relationship\resources\views/product/index.blade.php ENDPATH**/ ?>