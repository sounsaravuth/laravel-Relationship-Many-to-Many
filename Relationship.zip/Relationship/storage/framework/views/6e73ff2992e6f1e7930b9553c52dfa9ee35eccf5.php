<?php $__env->startSection('title',"Record detail"); ?>;
<?php $__env->startSection('table'); ?>
<div class="card">


    <div class="card-body">
        <ul>
            <dt><?php echo e($detailpro->proname); ?></dt>
            <dt><?php echo e($detailpro->qty); ?></dt>

            <?php $__currentLoopData = $detailpro->categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <dt><?php echo e($item->catename); ?></dt>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Application Laravel\Relationship\resources\views/product/detail.blade.php ENDPATH**/ ?>