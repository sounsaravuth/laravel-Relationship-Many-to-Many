<?php $__env->startSection('title',"Record Product"); ?>;
<?php $__env->startSection('table'); ?>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(url('updateproduct/'.$productedit->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form-group">
                <label for="Product">Product Name</label>
                <input type="text" class="form-control" name="proname" placeholder="Product name" value="<?php echo e($productedit->proname); ?>">
            </div>
            <div class="form-group">
                <label for="qty">Product Qty</label>
                <input type="number" class="form-control" name="qty" placeholder="Product qty" value="<?php echo e($productedit->qty); ?>">
            </div>
            <div class="form-group">
                <label for="my-select">Select Cate</label>
                <select id="my-select" class="form-control" name="categorys[]">
                    <?php $__currentLoopData = $fetchcate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemcate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($itemcate->id); ?>"><?php echo e($itemcate->catename); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-info">Update Product</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.Masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Application Laravel\Relationship\resources\views/product/edit.blade.php ENDPATH**/ ?>