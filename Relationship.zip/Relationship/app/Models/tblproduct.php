<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tblproduct extends Model
{
    use HasFactory;
    protected $fillable = ['proname','qty'];
    public function categorys(){
        return $this->belongsToMany(tblCategory::class,'tbl_product_categories','pro_id','cate_id')->withTimestamps();
    }
}
