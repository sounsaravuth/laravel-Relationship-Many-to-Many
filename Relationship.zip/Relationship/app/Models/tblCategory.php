<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tblCategory extends Model
{
    use HasFactory;
protected $fillable = ['catename'];

    public function products(){
        return $this->belongsToMany(tblproduct::class,'tbl_product_categories','pro_id','cate_id')->withTimestamps();
    }
}
