<?php

namespace App\Http\Controllers;

use App\Models\tblCategory;
use App\Models\tblproduct;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    //create by using relationshipt many to many
    public function productcreate(Request $request){

        $pro = tblproduct::create([
            'proname'=>$request->proname,
            'qty'=>$request->qty
        ]);
        $pro->categorys()->attach($request->categorys);
        return redirect('proview');
    }
    public function create(){
        $fetchcate = tblCategory::all();
        return view('product.create',compact('fetchcate'));
    }
    public function edit($id){
        $productedit = tblproduct::find($id);
        $fetchcate = tblCategory::all();
        return view('product.edit',compact('productedit','fetchcate'));
    }
    //update Product with relationship many to many
    public function update(Request $request){
            $update= tblproduct::updateOrCreate([
                'proname'=>$request->proname,
                'qty'=>$request->qty
            ]);
            $update->categorys()->sync($request->categorys);
            return redirect('proview');
    }


    //retive data Relationp Many To Many
    public function viewproductcate(){
        $show = tblproduct::with('categorys')->get();
        return view('product.index',compact('show'));
    }

    //delete product with relatonship
    public function destory($id){
        $deletepro = tblproduct::find($id);
        $deletepro->categorys()->detach();
        $deletepro->delete();
        return redirect('proview');
    }
    //view detail product by using relation many to many
    public function showDetail($id){
        $detailpro = tblproduct::with('categorys')->find($id);
        // return $detailpro;
        return view('product.detail',compact('detailpro'));
    }
}
