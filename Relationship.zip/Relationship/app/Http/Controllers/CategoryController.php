<?php

namespace App\Http\Controllers;

use App\Models\tblCategory;
use App\Models\tblproduct;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function categorycate(){
        $cate = tblCategory::create([
            'catename'=>'food'
        ]);

        return "Record Category Save Successfully";
    }
    //retive categry product
    public function procate(){
        $catepro = tblCategory::with('products')->get();
        return $catepro;
    }
}
