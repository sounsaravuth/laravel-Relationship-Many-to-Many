<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTblProductCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_product_categories', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('pro_id')->unsigned();
            $table->unsignedBigInteger('cate_id')->unsigned();
            $table->foreign('pro_id')->references('id')->on('tblproducts')->OnDelete('cascade');
            $table->foreign('cate_id')->references('id')->on('tbl_categories')->OnDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_product_categories');
    }
}
